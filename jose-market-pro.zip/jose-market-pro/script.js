/*
 José Market Pro - Frontend demo (simulado)
 - Muestra 5 productos por cada nicho y permite "analizar" (simulado)
 - Listado pre-generado; no conecta a APIs reales.
*/

const sampleData = [
  {
    niche: "Marketing Digital",
    products: [
      {name:"Curso Funnels PRO", price:49, trend:"+12%", source:"Hotmart"},
      {name:"Plantillas Canva Ads", price:19, trend:"+8%", source:"Etsy"},
      {name:"Guía SEO 2025", price:29, trend:"+15%", source:"Udemy"},
      {name:"Masterclass Email", price:39, trend:"+6%", source:"Hotmart"},
      {name:"Pack Creativos 50", price:14, trend:"+3%", source:"Etsy"}
    ]
  },
  {
    niche: "Desarrollo Personal",
    products: [
      {name:"Hábitos 90d", price:29, trend:"+7%", source:"Hotmart"},
      {name:"Meditación Guiada Pack", price:19, trend:"+9%", source:"Etsy"},
      {name:"Coaching Intensivo", price:99, trend:"+5%", source:"Udemy"},
      {name:"Audio Motivacional", price:9, trend:"+2%", source:"Hotmart"},
      {name:"Plantilla Diario", price:7, trend:"+1%", source:"Etsy"}
    ]
  },
  {
    niche: "Productividad",
    products: [
      {name:"Sistema GTD Simplificado", price:35, trend:"+11%", source:"Hotmart"},
      {name:"Templates Notion PRO", price:12, trend:"+4%", source:"Etsy"},
      {name:"Curso Pomodoro Avanzado", price:22, trend:"+6%", source:"Udemy"},
      {name:"Checklist Empresarial", price:18, trend:"+3%", source:"Hotmart"},
      {name:"Pack Widgets", price:6, trend:"+2%", source:"Etsy"}
    ]
  }
]

// DOM refs
const cardsContainer = document.getElementById('cardsContainer')
const totalNiches = document.getElementById('total-niches')
const totalProducts = document.getElementById('total-products')
const detailArea = document.getElementById('detailArea')
const searchBtn = document.getElementById('searchBtn')
const queryInput = document.getElementById('query')
const refreshBtn = document.getElementById('refreshBtn')

function renderAll(data){
  cardsContainer.innerHTML = ''
  let prodCount = 0
  data.forEach(group=>{
    prodCount += group.products.length
    const card = document.createElement('div')
    card.className = 'card'
    const title = document.createElement('h3')
    title.textContent = group.niche
    card.appendChild(title)

    const list = document.createElement('div')
    list.style.marginTop = '8px'
    group.products.forEach(p=>{
      const row = document.createElement('div')
      row.style.display = 'flex'
      row.style.justifyContent = 'space-between'
      row.style.alignItems = 'center'
      row.style.padding = '8px 0'
      const left = document.createElement('div')
      left.innerHTML = '<div style="font-weight:700">'+p.name+'</div><div class="meta">'+p.source+'</div>'
      const right = document.createElement('div')
      right.innerHTML = '<div class="price">$'+p.price+'</div><div class="trend">'+p.trend+'</div>'
      row.appendChild(left)
      row.appendChild(right)
      row.style.cursor = 'pointer'
      row.onclick = ()=> showDetail(group.niche, p)
      list.appendChild(row)
    })

    const footer = document.createElement('div')
    footer.style.display='flex'
    footer.style.justifyContent='space-between'
    footer.style.alignItems='center'
    footer.style.marginTop='10px'
    footer.innerHTML = '<span class="tag">Top 5</span><span class="meta">Tendencia general: +8%</span>'

    card.appendChild(list)
    card.appendChild(footer)
    cardsContainer.appendChild(card)
  })
  totalNiches.textContent = 'Niches: ' + data.length
  totalProducts.textContent = 'Productos: ' + prodCount
}

function showDetail(niche, product){
  detailArea.innerHTML = `
    <h3>${product.name}</h3>
    <p><strong>Nicho:</strong> ${niche}</p>
    <p><strong>Precio promedio:</strong> $${product.price}</p>
    <p><strong>Fuente (simulada):</strong> ${product.source}</p>
    <p><strong>Tendencia:</strong> ${product.trend}</p>
    <p><em>Este detalle es una vista demo. Para conectar datos reales, posteriormente se integra backend o APIs.</em></p>
  `
}

function simulateAnalysis(query){
  // Simula un "análisis" buscando por palabra en nombres y nichos
  const q = (query || '').toLowerCase().trim()
  if(!q) return sampleData
  return sampleData.map(group=>{
    const matches = group.products.filter(p=> (p.name+p.source).toLowerCase().includes(q) || group.niche.toLowerCase().includes(q))
    return { niche: group.niche, products: matches }
  }).filter(g=>g.products.length>0)
}

// events
searchBtn.onclick = ()=> {
  const q = queryInput.value
  const res = simulateAnalysis(q)
  renderAll(res)
  // small visual feedback
  if(res.length===0){
    detailArea.innerHTML = '<p>No se encontraron coincidencias. Prueba con otras palabras.</p>'
  }
}

refreshBtn.onclick = ()=> {
  // "Actualizar datos" simplemente re-renderiza la muestra (simulado)
  renderAll(sampleData)
  detailArea.innerHTML = '<p>Datos refrescados (simulado).</p>'
}

// initial render
renderAll(sampleData)
