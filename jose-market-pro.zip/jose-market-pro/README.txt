José Market Pro - Frontend demo
-------------------------------
Estructura:
- index.html
- style.css
- script.js
- images/

Instrucciones para subir desde teléfono a GitHub Pages:
1) Abre github.com y crea un nuevo repositorio con nombre "jose-market-pro".
2) En el repositorio toca "Add file" -> "Upload files" y sube los archivos (index.html, style.css, script.js) y la carpeta images.
3) Commit changes.
4) Ve a Settings -> Pages -> Branch: main, Folder: / (root). Save.
5) Espera 2-5 minutos y abre: https://TU_USUARIO.github.io/jose-market-pro/

Nota: Este es un demo frontend listo para GitHub Pages. Si luego deseas backend o integración real con Hotmart/Udemy, lo añadimos.
