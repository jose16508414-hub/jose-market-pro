from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

app = FastAPI(title="José Market Pro - API (i18n)")

app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

@app.middleware("http")
async def add_locale(request: Request, call_next):
    lang = request.headers.get("accept-language", "es").split(",")[0]
    request.state.lang = lang
    response = await call_next(request)
    return response

@app.get("/api/v1/ping")
async def ping(request: Request):
    return JSONResponse({"status":"ok","lang":request.state.lang})
