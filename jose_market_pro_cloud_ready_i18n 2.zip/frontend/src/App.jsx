
import React, {useState} from 'react';
import { useTranslation } from 'react-i18next';
import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000/api/v1";

function LanguageSelector(){ 
  const { i18n } = useTranslation();
  return (
    <select value={i18n.language} onChange={(e)=>i18n.changeLanguage(e.target.value)} style={{marginLeft:20}}>
      <option value="es">Español</option>
      <option value="en">English</option>
    </select>
  )
}

function ProductCard({p}) {
  const { t } = useTranslation();
  return (
    <div style={{width:180, padding:12, background:'#0f1724', borderRadius:8, color:'#fff', marginRight:12}}>
      <div style={{height:100, background:'#0b1220', borderRadius:6, marginBottom:8}} />
      <div style={{fontWeight:600}}>{p.title}</div>
      <div style={{color:'#9ca3af'}}>{t('precio')}: ${p.price}</div>
      <div style={{marginTop:8}}>
        <button style={{background:'#3b82f6', color:'#fff', padding:'8px 10px', borderRadius:6, marginRight:6}}>{t('visualizar')}</button>
        <button style={{background:'#10b981', color:'#fff', padding:'8px 10px', borderRadius:6}}>{t('descargar')}</button>
      </div>
    </div>
  )
}

export default function App(){
  const { t } = useTranslation();
  const [products, setProducts] = useState([
    {title:'Guía práctica IA', price:47},
    {title:'Curso Intro AI', price:32},
    {title:'Guía marketing digital', price:25},
  ]);

  return (
    <div style={{fontFamily:'Inter, Arial', background:'#071029', minHeight:'100vh', color:'#e6eef8'}}>
      <header style={{display:'flex', alignItems:'center', padding:20}}>
        <h2 style={{margin:0}}>{t('app_title')}</h2>
        <div style={{flex:1}} />
        <input placeholder={t('search_placeholder')} style={{padding:10, borderRadius:8, width:420}} />
        <LanguageSelector />
      </header>

      <main style={{display:'flex', padding:20, gap:20}}>
        <aside style={{width:220, background:'#071025', padding:20, borderRadius:8}}>
          <nav>
            <div style={{padding:10, marginBottom:6, background:'#0b1220', borderRadius:6}}>Inicio</div>
            <div style={{padding:10, marginBottom:6}}>Análisis</div>
            <div style={{padding:10, marginBottom:6}}>Productos</div>
            <div style={{padding:10, marginBottom:6}}>Configuración</div>
          </nav>
        </aside>

        <section style={{flex:1}}>
          <div style={{display:'flex', gap:16, marginBottom:16}}>
            <div style={{flex:2, background:'#0b1220', padding:18, borderRadius:8}}>
              <h3>{t('panel_ia')}</h3>
              <p>Curso de Inteligencia Artificial — Precio promedio <strong>$47 USD</strong></p>
            </div>
            <div style={{flex:1, background:'#0b1220', padding:18, borderRadius:8}}>
              <h3>Rendimiento</h3>
              <p>Últimas 12 semanas</p>
            </div>
          </div>

          <h4>{t('top_products')}</h4>
          <div style={{display:'flex', marginTop:12}}>
            {products.map((p,i)=>(<ProductCard p={p} key={i}/>))}
          </div>
        </section>
      </main>
    </div>
  )
}
